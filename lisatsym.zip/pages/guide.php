<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Submission Guideline
      </h1>
      <ol class="breadcrumb">
        <li><a href="index.php"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Submission Guideline</li>
      </ol>
	  </section>
		<section class="content">
			<div class="row">
				<div class="col-md-12" align="center">
					<img align="center" src="dist/img/peer-review-process.png" width="70%" />
				</div>
			</div>
		</section>
	</div>
</div>