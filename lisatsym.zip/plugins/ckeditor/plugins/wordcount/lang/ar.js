// Arabic Translation by Amine BENHAMIDA

CKEDITOR.plugins.setLang('wordcount', 'ar', {
    WordCount: 'كلمات:',
    CharCount: 'حروف:',
    CharCountWithHTML: 'حروف مع إتش تي إم إل',
    Paragraphs: 'فقرات',
    pasteWarning: 'لا يمكن اضافة هذا المحتوى لانه تجاوز الحد الاقصى',
    Selected: 'محدد: ',
    title: 'احصائيات'
});
